
![Analog Watch made in JS](https://github.com/Sasicrastko/JavaScript-Analog-Clock/blob/master/clock2.png)
